/**
 * Tutorial Interactivo: Cómo Subir e Importar Archivos Excel en 8 Pasos
 * Sistema Integral de Control de Calidad de Válvulas PGP 2026
 */

import React, { useState } from 'react';
import { 
  X, 
  FileSpreadsheet, 
  CheckCircle, 
  ArrowRight, 
  ArrowLeft, 
  Download, 
  Layers, 
  AlertTriangle, 
  ShieldCheck, 
  Database, 
  HelpCircle,
  FileCheck,
  Table,
  Columns,
  RefreshCw,
  HardDrive
} from 'lucide-react';
import { excelService } from '../services/excelService';

interface ExcelTutorialModalProps {
  onClose: () => void;
  onOpenImportWizard: () => void;
}

export const ExcelTutorialModal: React.FC<ExcelTutorialModalProps> = ({
  onClose,
  onOpenImportWizard
}) => {
  const [activeStep, setActiveStep] = useState<number>(1);

  const steps = [
    {
      step: 1,
      title: "1. Preparación del Archivo Excel",
      subtitle: "Formatos admitidos y estructura de columnas recomendada",
      icon: FileSpreadsheet,
      badge: "Formato .xlsx / .csv",
      content: (
        <div className="space-y-4">
          <p className="text-sm text-slate-300">
            El sistema admite libros oficiales de Excel en formato <strong className="text-emerald-400">.xlsx</strong>, <strong className="text-emerald-400">.xls</strong> y archivos delimitados por coma <strong className="text-emerald-400">.csv</strong> de hasta 25 MB.
          </p>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">Recomendaciones de Estructura:</h4>
            <ul className="text-xs space-y-2 text-slate-300">
              <li className="flex items-start space-x-2">
                <span className="text-emerald-400 font-bold mt-0.5">✓</span>
                <span><strong>Fila de Encabezados:</strong> Debe estar preferentemente en la primera o segunda fila con nombres claros (ej. <em>TAG, O/T, TIPO, RATING, DIÁMETRO</em>).</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="text-emerald-400 font-bold mt-0.5">✓</span>
                <span><strong>Columna TAG obligatoria:</strong> Cada válvula debe poseer un TAG único (ej. <em>100-XV-0101, 200-FV-0205</em>) que actúa como clave primaria de trazabilidad.</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="text-emerald-400 font-bold mt-0.5">✓</span>
                <span><strong>Sin celdas combinadas en datos:</strong> Evita combinar celdas en el cuerpo de la tabla para que el motor pueda procesar cada fila de forma independiente.</span>
              </li>
            </ul>
          </div>

          <div className="p-3 bg-blue-950/40 border border-blue-500/30 rounded-xl flex items-center justify-between">
            <div className="text-xs text-blue-200">
              <span className="font-semibold text-white">¿No tienes el archivo base?</span> Descarga la plantilla oficial preformateada lista para rellenar.
            </div>
            <button
              onClick={() => excelService.downloadOfficialPgpTemplate()}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shrink-0 ml-3"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Bajar Plantilla</span>
            </button>
          </div>
        </div>
      )
    },
    {
      step: 2,
      title: "2. Selección y Análisis de Hojas",
      subtitle: "Detección automática de pestañas y filas vacías",
      icon: Layers,
      badge: "Multi-hoja",
      content: (
        <div className="space-y-4">
          <p className="text-sm text-slate-300">
            Al arrastrar y soltar el archivo en la zona de carga, el sistema analiza la estructura interna del libro sin subir nada a servidores externos.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1.5">
              <span className="text-blue-400 font-bold">Selector de Hoja:</span>
              <p className="text-slate-400">Si tu Excel contiene múltiples pestañas (ej. <em>Listado General</em>, <em>Pruebas PH</em>, <em>Punch List</em>), podrás elegir exactamente cuál deseas importar.</p>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1.5">
              <span className="text-emerald-400 font-bold">Detección de Encabezado:</span>
              <p className="text-slate-400">Si tu archivo incluye logos o títulos en las primeras líneas, el asistente te permite indicar en qué fila comienzan los encabezados de columnas.</p>
            </div>
          </div>

          <div className="p-3 bg-slate-850/70 border border-slate-750 rounded-lg text-xs text-slate-300">
            <strong>Dato Técnico:</strong> Se eliminan automáticamente filas vacías al inicio y al final para evitar registros falsos.
          </div>
        </div>
      )
    },
    {
      step: 3,
      title: "3. Mapeo Inteligente de Columnas",
      subtitle: "Homologación con alias de la matriz PGP",
      icon: Columns,
      badge: "Auto-Matching",
      content: (
        <div className="space-y-4">
          <p className="text-sm text-slate-300">
            El motor reconoce automáticamente más de <strong>50 alias industriales</strong> en español e inglés.
          </p>

          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
            <div className="text-xs font-semibold text-slate-200 mb-2">Ejemplo de Mapeo Automático:</div>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between items-center py-1 border-b border-slate-850">
                <span className="text-slate-400">Columna en tu Excel: <code className="text-blue-300">TAG VALVULA</code></span>
                <span className="text-emerald-400 font-mono">→ tag (Obligatorio)</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-855">
                <span className="text-slate-400">Columna en tu Excel: <code className="text-blue-300">O/T N°</code></span>
                <span className="text-emerald-400 font-mono">→ ot</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-855">
                <span className="text-slate-400">Columna en tu Excel: <code className="text-blue-300">CLASE / RATING</code></span>
                <span className="text-emerald-400 font-mono">→ clase_rating</span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="text-slate-400">Columna en tu Excel: <code className="text-blue-300">P. CARCASA BAR</code></span>
                <span className="text-emerald-400 font-mono">→ presion_carcasa_requerida_bar</span>
              </div>
            </div>
          </div>

          <p className="text-xs text-slate-400">
            Si una columna no coincide exactamente, puedes cambiarla manualmente mediante el selector desplegable de cada campo.
          </p>
        </div>
      )
    },
    {
      step: 4,
      title: "4. Validación Técnica y Criterios Industriales",
      subtitle: "Revisión bajo normas API 598, ASME B16.34 y Normas Chilenas NCh",
      icon: ShieldCheck,
      badge: "Validación QA/QC",
      content: (
        <div className="space-y-4">
          <p className="text-sm text-slate-300">
            Antes de guardar cualquier dato, el motor somete cada registro a reglas estrictas de ingeniería:
          </p>

          <div className="space-y-2.5 text-xs">
            <div className="p-3 bg-slate-950 border-l-4 border-emerald-500 rounded-r-xl">
              <strong className="text-emerald-300">Validación de Presiones Hidrostáticas:</strong>
              <p className="text-slate-400 mt-0.5">Comprueba que la presión de carcasa cumpla al menos 1.5 veces la presión nominal de diseño y que el asiento cumpla 1.1 veces, conforme a <strong className="text-slate-200">API 598</strong> y <strong className="text-slate-200">NCh 700 / NCh 1360</strong>.</p>
            </div>
            <div className="p-3 bg-slate-950 border-l-4 border-amber-500 rounded-r-xl">
              <strong className="text-amber-300">Alertas de Formato y Unidades:</strong>
              <p className="text-slate-400 mt-0.5">Detecta ratings no normalizados (ej. <em>300 lbs</em> frente a <em>300#</em>) y convierte automáticamente unidades a bar y pulgadas.</p>
            </div>
            <div className="p-3 bg-slate-950 border-l-4 border-blue-500 rounded-r-xl">
              <strong className="text-blue-300">Detección de Duplicados en Base de Datos:</strong>
              <p className="text-slate-400 mt-0.5">Identifica si el TAG ya existe para activar el comparador visual de diferencias (Diff).</p>
            </div>
          </div>
        </div>
      )
    },
    {
      step: 5,
      title: "5. Vista Previa y Filtros de Estado",
      subtitle: "Revisión fila por fila con semáforo de integridad",
      icon: Table,
      badge: "Semáforo QA",
      content: (
        <div className="space-y-4">
          <p className="text-sm text-slate-300">
            En la vista previa se presenta la matriz completa categorizada en tres estados:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl space-y-1">
              <div className="flex items-center space-x-1.5 text-emerald-400 font-bold">
                <CheckCircle className="w-4 h-4" />
                <span>Válidas (100% OK)</span>
              </div>
              <p className="text-slate-400">Listas para inserción directa en la base de datos sin observaciones.</p>
            </div>

            <div className="p-3 bg-amber-950/40 border border-amber-500/30 rounded-xl space-y-1">
              <div className="flex items-center space-x-1.5 text-amber-400 font-bold">
                <AlertTriangle className="w-4 h-4" />
                <span>Advertencias</span>
              </div>
              <p className="text-slate-400">Datos con campos opcionales vacíos o redondeo de presiones admisible.</p>
            </div>

            <div className="p-3 bg-rose-950/40 border border-rose-500/30 rounded-xl space-y-1">
              <div className="flex items-center space-x-1.5 text-rose-400 font-bold">
                <AlertTriangle className="w-4 h-4" />
                <span>Errores Bloqueantes</span>
              </div>
              <p className="text-slate-400">Filas sin TAG o con inconsistencias críticas. Serán omitidas o corregidas.</p>
            </div>
          </div>

          <p className="text-xs text-slate-400">
            Puedes hacer clic en cualquier filtro para examinar únicamente las filas que tengan advertencias o errores.
          </p>
        </div>
      )
    },
    {
      step: 6,
      title: "6. Comparación de Diferencias (Diff)",
      subtitle: "Control estricto contra sobrescrituras accidentales",
      icon: RefreshCw,
      badge: "Anti-Sobrescritura",
      content: (
        <div className="space-y-4">
          <p className="text-sm text-slate-300">
            <strong className="text-amber-400">Regla Obligatoria PGP:</strong> Ningún dato existente se sobrescribe a ciegas.
          </p>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3 text-xs">
            <div className="font-semibold text-slate-200">Para cada registro con coincidencia de TAG podrás:</div>
            <ul className="space-y-2 text-slate-300">
              <li className="flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-semibold">Actualizar</span>
                <span>Modificar únicamente los campos nuevos aprobados por el usuario.</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-semibold">Omitir</span>
                <span>Conservar la información original intacta en el sistema.</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-semibold">Ver Diff</span>
                <span>Comparar celda por celda los valores anteriores frente a los entrantes.</span>
              </li>
            </ul>
          </div>
        </div>
      )
    },
    {
      step: 7,
      title: "7. Carga Transaccional y Persistencia",
      subtitle: "Almacenamiento seguro en PostgreSQL / Motor Relacional",
      icon: Database,
      badge: "ACID Transaccional",
      content: (
        <div className="space-y-4">
          <p className="text-sm text-slate-300">
            Al pulsar <strong className="text-emerald-400">“Confirmar e Importar a Base de Datos”</strong>:
          </p>

          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2 text-xs text-slate-300">
            <div className="flex items-center space-x-2 text-emerald-400 font-bold">
              <CheckCircle className="w-4 h-4" />
              <span>Transacción Atómica Segura</span>
            </div>
            <p className="text-slate-400">
              Todos los registros se procesan en bloque. Si ocurriera un fallo crítico imprevisto, se ejecuta un rollback para preservar la consistencia de los datos existentes.
            </p>
            <p className="text-slate-400">
              Se genera automáticamente una entrada en la tabla <code className="text-blue-300">historial_importaciones</code> y en la tabla inmutable <code className="text-purple-300">auditoria_cambios</code> con la firma del usuario responsable.
            </p>
          </div>
        </div>
      )
    },
    {
      step: 8,
      title: "8. Reporte Final y Trabajo con Google Drive",
      subtitle: "Resumen estadístico y flujo de colaboración local con Drive",
      icon: HardDrive,
      badge: "Colaboración",
      content: (
        <div className="space-y-4">
          <p className="text-sm text-slate-300">
            Al concluir la importación obtendrás un reporte consolidado con:
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
            <div className="p-2.5 bg-slate-950 border border-slate-800 rounded-lg">
              <div className="font-bold text-white text-base">Total</div>
              <div className="text-slate-400 text-[11px]">Procesadas</div>
            </div>
            <div className="p-2.5 bg-emerald-950/40 border border-emerald-500/30 rounded-lg">
              <div className="font-bold text-emerald-400 text-base">Insertadas</div>
              <div className="text-slate-400 text-[11px]">Nuevos TAGs</div>
            </div>
            <div className="p-2.5 bg-blue-950/40 border border-blue-500/30 rounded-lg">
              <div className="font-bold text-blue-400 text-base">Actualizadas</div>
              <div className="text-slate-400 text-[11px]">Con Diff</div>
            </div>
            <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-lg">
              <div className="font-bold text-slate-300 text-base">Omitidas</div>
              <div className="text-slate-400 text-[11px]">Duplicadas</div>
            </div>
          </div>

          <div className="p-3.5 bg-indigo-950/40 border border-indigo-500/30 rounded-xl space-y-2 text-xs text-indigo-200">
            <div className="font-bold text-indigo-300 flex items-center space-x-1.5">
              <HardDrive className="w-4 h-4 text-indigo-400" />
              <span>Flujo Recomendado de Trabajo Local con Google Drive / OneDrive:</span>
            </div>
            <p className="text-slate-300">
              Mantén el archivo Excel oficial en una carpeta sincronizada con la app de escritorio de <strong>Google Drive</strong> (ej. <code>G:\Mi Unidad\PGP_Calidad_Valvulas\</code>). El equipo técnico edita colaborativamente en Excel Web o de escritorio, y cuando se requiera consolidar, se arrastra el archivo directamente a este asistente. Cero costo de API, total trazabilidad y control de versiones nativo en Drive.
            </p>
          </div>
        </div>
      )
    }
  ];

  const current = steps[activeStep - 1];
  const StepIcon = current.icon;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Cabecera del Tutorial */}
        <div className="px-6 py-4 bg-gradient-to-r from-slate-950 via-slate-900 to-blue-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <HelpCircle className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-bold text-white">Guía Tutorial: Importación de Excel</h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30">
                  Flujo de 8 Pasos
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Aprende a preparar, validar e importar matrices de válvulas sin errores ni duplicados
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Barra de Progreso de Pasos (1 a 8) */}
        <div className="bg-slate-950 border-b border-slate-800 px-6 py-3 overflow-x-auto">
          <div className="flex items-center space-x-1.5 min-w-[540px]">
            {steps.map(s => (
              <button
                key={s.step}
                onClick={() => setActiveStep(s.step)}
                className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1 transition ${
                  activeStep === s.step
                    ? 'bg-blue-600 text-white shadow-sm'
                    : s.step < activeStep
                    ? 'bg-slate-800 text-emerald-400 hover:bg-slate-750'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>Paso {s.step}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Contenido del Paso Activo */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
                <StepIcon className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-base font-bold text-white">{current.title}</h4>
                <p className="text-xs text-slate-400">{current.subtitle}</p>
              </div>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 font-mono">
              {current.badge}
            </span>
          </div>

          {current.content}
        </div>

        {/* Pie con Navegación y Botón de Acción Directa */}
        <div className="px-6 py-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveStep(prev => Math.max(1, prev - 1))}
              disabled={activeStep === 1}
              className="px-3 py-2 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-medium flex items-center space-x-1 transition"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Anterior</span>
            </button>
            <button
              onClick={() => setActiveStep(prev => Math.min(steps.length, prev + 1))}
              disabled={activeStep === steps.length}
              className="px-3 py-2 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-medium flex items-center space-x-1 transition"
            >
              <span>Siguiente</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-3.5 py-2 rounded-lg text-slate-400 hover:text-slate-200 text-xs font-medium"
            >
              Cerrar Tutorial
            </button>
            <button
              onClick={() => {
                onClose();
                onOpenImportWizard();
              }}
              className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-700/20 flex items-center space-x-1.5 transition"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Ir al Asistente de Subida</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
