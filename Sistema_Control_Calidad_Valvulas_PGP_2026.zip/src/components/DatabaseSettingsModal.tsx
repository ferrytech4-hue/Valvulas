/**
 * Módulo de Base de Datos PostgreSQL & Migraciones Supabase
 * Sistema Integral de Control de Calidad de Válvulas PGP 2026
 * Arquitectura de Costo Cero
 */

import React, { useState } from 'react';
import { 
  Database, 
  Download, 
  Copy, 
  Check, 
  RotateCcw, 
  Server, 
  ShieldCheck, 
  AlertTriangle,
  Code2,
  ExternalLink,
  Layers
} from 'lucide-react';
import { dbService, DatabaseConfig } from '../services/storageService';
import { useAuth } from '../services/authContext';

export const DatabaseSettingsModal: React.FC = () => {
  const { user, can } = useAuth();
  const [config, setConfig] = useState<DatabaseConfig>(() => dbService.getDatabaseConfig());
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'SCHEMA_SQL' | 'DUMP_SQL' | 'CONNECTION' | 'AUDIT'>('SCHEMA_SQL');

  const fullSqlDump = dbService.generateFullSqlDump();
  const auditLogs = dbService.getAuditLogs();

  const handleCopySql = () => {
    navigator.clipboard.writeText(fullSqlDump);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSql = () => {
    const blob = new Blob([fullSqlDump], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `PGP_2026_PostgreSQL_Dump_${new Date().toISOString().split('T')[0]}.sql`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleSaveConnection = (e: React.FormEvent) => {
    e.preventDefault();
    dbService.updateDatabaseConfig(config);
    alert('Configuración de base de datos guardada exitosamente.');
  };

  const handleResetFactory = () => {
    if (!window.confirm('¿Está seguro de reiniciar los datos a la muestra oficial PGP 2026? Se preservará la estructura pero se reiniciarán los registros.')) {
      return;
    }
    dbService.resetToFactorySampleData(user.nombre, user.rol);
    window.location.reload();
  };

  return (
    <div className="space-y-6">
      {/* Banner de Estado de Base de Datos */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-500/10 text-purple-400 border border-purple-500/20">
                <Server className="w-3.5 h-3.5 mr-1 text-purple-400" />
                PostgreSQL 15 / Supabase Free Tier
              </span>
              <span className="text-xs text-slate-400">Arquitectura Costo Cero</span>
            </div>
            <h2 className="text-xl font-bold text-white mt-1">Gestor de Base de Datos Relacional & Migraciones SQL</h2>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl">
              Esquema DDL relacional con soporte para claves foráneas, restricciones de unicidad en TAG, integridad referencial en cascada, índices B-Tree y reglas de negocio QA/QC.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleDownloadSql}
              className="flex items-center space-x-1.5 px-3.5 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow transition"
            >
              <Download className="w-4 h-4" />
              <span>Descargar Dump SQL Completo</span>
            </button>

            {can('MANAGE_DATABASE_SQL') && (
              <button
                onClick={handleResetFactory}
                className="flex items-center space-x-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 text-xs font-medium border border-slate-700 transition"
                title="Restaurar registros semilla originales PGP 2026"
              >
                <RotateCcw className="w-3.5 h-3.5 text-rose-400" />
                <span>Restaurar Datos Semilla</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Selector de Pestañas de Base de Datos */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-2 flex space-x-2 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('SCHEMA_SQL')}
          className={`px-3 py-2 rounded-lg transition ${
            activeTab === 'SCHEMA_SQL' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          Esquema DDL & Tablas
        </button>
        <button
          onClick={() => setActiveTab('DUMP_SQL')}
          className={`px-3 py-2 rounded-lg transition ${
            activeTab === 'DUMP_SQL' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          Dump SQL de Datos Actuales
        </button>
        <button
          onClick={() => setActiveTab('CONNECTION')}
          className={`px-3 py-2 rounded-lg transition ${
            activeTab === 'CONNECTION' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          Conexión Supabase PostgreSQL
        </button>
        <button
          onClick={() => setActiveTab('AUDIT')}
          className={`px-3 py-2 rounded-lg transition ${
            activeTab === 'AUDIT' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          Trazabilidad & Auditoría ({auditLogs.length})
        </button>
      </div>

      {/* CONTENIDO TAB 1: ESQUEMA DDL */}
      {activeTab === 'SCHEMA_SQL' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white">Estructura Relacional Oficial (pgp_valvulas_schema.sql)</h3>
              <p className="text-xs text-slate-400">7 tablas relacionales preparadas para el editor SQL de Supabase</p>
            </div>
            <button
              onClick={handleCopySql}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copiado al Portapapeles' : 'Copiar SQL'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
              <span className="font-bold text-purple-400 font-mono">valvulas</span>
              <p className="text-[11px] text-slate-400 mt-1">Maestro técnico con 26 campos, índice único en TAG y OT.</p>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
              <span className="font-bold text-blue-400 font-mono">pruebas_hidraulicas</span>
              <p className="text-[11px] text-slate-400 mt-1">Protocolos API 598, presiones de carcasa y asiento, manómetros.</p>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
              <span className="font-bold text-amber-400 font-mono">punch_list</span>
              <p className="text-[11px] text-slate-400 mt-1">No conformidades con criticidad A/B/C y bloqueo de liberación.</p>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
              <span className="font-bold text-emerald-400 font-mono">adjuntos</span>
              <p className="text-[11px] text-slate-400 mt-1">Metadata de archivos, MTRs y hashes de integridad SHA-256.</p>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
              <span className="font-bold text-slate-300 font-mono">usuarios</span>
              <p className="text-[11px] text-slate-400 mt-1">Control de acceso RBAC con 5 roles técnicos predefinidos.</p>
            </div>
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
              <span className="font-bold text-slate-300 font-mono">auditoria_cambios</span>
              <p className="text-[11px] text-slate-400 mt-1">Registro inmutable de cada transacción e inserción.</p>
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 overflow-x-auto max-h-[40vh] font-mono text-xs text-slate-300">
            <pre>{fullSqlDump.slice(0, 2500) + '\n\n-- [... Continuación en descarga de dump completo ...]'}</pre>
          </div>
        </div>
      )}

      {/* CONTENIDO TAB 2: DUMP SQL */}
      {activeTab === 'DUMP_SQL' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white">Respaldo y Volcado SQL Completo</h3>
              <p className="text-xs text-slate-400">Sentencias INSERT con ON CONFLICT DO UPDATE listas para replicación</p>
            </div>
            <button
              onClick={handleDownloadSql}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Descargar .sql</span>
            </button>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 overflow-x-auto max-h-[50vh] font-mono text-xs text-slate-300">
            <pre>{fullSqlDump}</pre>
          </div>
        </div>
      )}

      {/* CONTENIDO TAB 3: CONEXIÓN SUPABASE */}
      {activeTab === 'CONNECTION' && (
        <form onSubmit={handleSaveConnection} className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 text-xs">
          <div className="pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white">Configuración de Conexión Supabase (PostgreSQL Gratuito)</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Ingrese las credenciales del proyecto de Supabase Free Tier para habilitar sincronización en la nube.
            </p>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block font-medium text-slate-400 mb-1">Modo de Persistencia</label>
              <select
                value={config.mode}
                onChange={(e) => setConfig({ ...config, mode: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
              >
                <option value="LOCAL_ENGINE">Motor Local de Alta Velocidad (Offline Ready & IndexedDB)</option>
                <option value="SUPABASE_POSTGRES">Supabase PostgreSQL en la Nube (Free Tier)</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-400 mb-1">VITE_SUPABASE_URL</label>
              <input
                type="text"
                placeholder="https://xyzcompany.supabase.co"
                value={config.supabaseUrl}
                onChange={(e) => setConfig({ ...config, supabaseUrl: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg font-mono text-slate-200"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-400 mb-1">VITE_SUPABASE_ANON_KEY</label>
              <input
                type="password"
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                value={config.supabaseAnonKey}
                onChange={(e) => setConfig({ ...config, supabaseAnonKey: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg font-mono text-slate-200"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-400 mb-1">DATABASE_URL (Cadena PostgreSQL)</label>
              <input
                type="password"
                placeholder="postgresql://postgres:[PASSWORD]@db.xyzcompany.supabase.co:5432/postgres"
                value={config.databaseUrl}
                onChange={(e) => setConfig({ ...config, databaseUrl: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg font-mono text-slate-200"
              />
            </div>
          </div>

          <div className="flex justify-end pt-3">
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold"
            >
              Guardar Configuración
            </button>
          </div>
        </form>
      )}

      {/* CONTENIDO TAB 4: AUDITORÍA */}
      {activeTab === 'AUDIT' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white">Historial Inmutable de Auditoría</h3>
            <p className="text-xs text-slate-400">Registro cronológico de todas las modificaciones y transacciones</p>
          </div>

          <div className="divide-y divide-slate-800 max-h-[50vh] overflow-y-auto">
            {auditLogs.map(a => (
              <div key={a.id} className="py-2.5 flex items-start justify-between text-xs">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-mono font-bold text-purple-400">{a.accion}</span>
                    <span className="text-slate-300 font-semibold">{a.entidad}</span>
                    <span className="text-blue-400 font-mono font-bold">{a.tag}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Operador: <strong className="text-slate-300">{a.usuario}</strong> ({a.rol})
                  </p>
                  <p className="text-[11px] text-slate-500 font-mono mt-0.5 truncate max-w-2xl">{a.cambios}</p>
                </div>
                <span className="text-[10px] text-slate-500 font-mono shrink-0">
                  {new Date(a.timestamp).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
